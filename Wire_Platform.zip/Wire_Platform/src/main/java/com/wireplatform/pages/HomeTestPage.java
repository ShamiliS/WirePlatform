package main.java.com.wireplatform.pages;

import org.openqa.selenium.By;

public class HomeTestPage {

	public static final By imgHeaderLogo = By
			.xpath("//img[@class='header-logo']");

	public static final By lblSignup = By
			.xpath("//a[contains(@class,'sign-up')]");

	public static final By lblFAQ = By.xpath("//a[@class='account-action']");

	public static By getLblfaq() {
		return lblFAQ;
	}

	public static By getLblsignup() {
		return lblSignup;
	}

	public static By getImgheaderlogo() {
		return imgHeaderLogo;
	}

}