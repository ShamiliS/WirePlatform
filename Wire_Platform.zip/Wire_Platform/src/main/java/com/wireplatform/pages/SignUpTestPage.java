package main.java.com.wireplatform.pages;

import org.openqa.selenium.By;

public class SignUpTestPage {

	public static final By lblFormheader = By
			.xpath("//div[@class='Form__header']/h3");

	public static final By edtFirstname = By.id("firstName");

	public static final By edtLastname = By.id("lastName");

	public static final By edtEmail = By.id("email");

	public static final By edtBirthdate = By.id("birthdate");

	public static final By edtMobile = By.id("mobile");

	public static final By edtPassword = By.id("password");

	public static final By chkSubscribe = By
			.xpath("//md-checkbox[contains(@class,'ng-valid')]");

	public static final By chkIAgree = By.xpath("//*[@id='agreeTerms']");

	public static final By lnkRegister = By.xpath("//button[contains(@type,'submit')]");

	public static By getLblformheader() {
		return lblFormheader;
	}

	public static By getEdtfirstname() {
		return edtFirstname;
	}

	public static By getEdtlastname() {
		return edtLastname;
	}

	public static By getEdtemail() {
		return edtEmail;
	}

	public static By getEdtbirthdate() {
		return edtBirthdate;
	}

	public static By getEdtmobile() {
		return edtMobile;
	}

	public static By getEdtpassword() {
		return edtPassword;
	}

	public static By getChksubscribe() {
		return chkSubscribe;
	}

	public static By getChkiagree() {
		return chkIAgree;
	}

	public static By getLnkregister() {
		return lnkRegister;
	}

}
