package main.java.com.wireplatform.pages;

import org.openqa.selenium.By;

public class OrderSummaryTestPage {

	public static final By lnkordersummary = By
			.xpath("//a[text()='Order Summary']");

	public static By getLnkordersummary() {
		return lnkordersummary;
	}

}
