package main.java.com.wireplatform.StepDefinitions;

import java.util.Map;

import main.java.com.wireplatform.CommonUtils;
import main.java.com.wireplatform.PageFactory.SignUpTestPage;

import org.openqa.selenium.By;
import org.testng.Reporter;

import cucumber.api.java.en.Then;

public class SignUpPage extends CommonUtils {

	@Then("^I should see Sign up to Travelex Wire$")
	public void I_should_see_Sign_up_to_Travelex_Wire() throws Throwable {

		By lblHeader = SignUpTestPage.getLblformheader();
		if (driver.findElement(lblHeader).isDisplayed()) {
			Reporter.log("I am in Sign up to Travelex Wire page");
		} else {
			Reporter.log("Error on page");
		}

	}

	@Then("^I enter all the mandatory fields with valid data$")
	public void I_enter_all_the_mandatory_fields_with_valid_data()
			throws Throwable {
		By edtFname = SignUpTestPage.getEdtfirstname();
		By edtLname = SignUpTestPage.getEdtlastname();
		By edtEmail = SignUpTestPage.getEdtemail();
		By edtDOB = SignUpTestPage.getEdtbirthdate();
		By edtMobile = SignUpTestPage.getEdtmobile();
		By edtPassword = SignUpTestPage.getEdtpassword();
		By chkSubscribe = SignUpTestPage.getChksubscribe();
		By chkIagree = SignUpTestPage.getChkiagree();
		By btnRegister = SignUpTestPage.getLnkregister();

		Map<String, String> userDetails = CommonUtils.readDatafromXMLFile();

		driver.findElement(edtFname).sendKeys(userDetails.get("Firstname"));
		driver.findElement(edtLname).sendKeys(userDetails.get("Lastname"));
		driver.findElement(edtEmail).sendKeys(userDetails.get("Email"));
		driver.findElement(edtDOB).sendKeys(userDetails.get("DOB"));
		driver.findElement(edtMobile).sendKeys(userDetails.get("Mobile"));
		driver.findElement(edtPassword).sendKeys(userDetails.get("Password"));

		driver.findElement(chkSubscribe).click();
		driver.findElement(chkIagree).click();

		String winHandleBefore = driver.getWindowHandle();
		for (String winHandle : driver.getWindowHandles()) {
			driver.switchTo().window(winHandle);
		}
		driver.close();
		driver.switchTo().window(winHandleBefore);

		driver.findElement(btnRegister).click();
	}
}
