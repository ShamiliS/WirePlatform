package main.java.com.wireplatform.StepDefinitions;

import java.util.List;
import java.util.Map;

import main.java.com.wireplatform.CommonUtils;
import main.java.com.wireplatform.PageFactory.HomeTestPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HomePage {

	static WebDriver driver;
	
	@Given("^launch application URL$")
	public void launch_application_URL(DataTable launchDetails)
			throws Throwable {

		List<Map<String, String>> data = launchDetails.asMaps();
		String browserType = data.get(0).get("BrowserType");
		String appURL = data.get(0).get("AppURL");

		driver = CommonUtils.setDriver(browserType, appURL);
	}

	@Then("^I am on home page$")
	public void I_am_on_home_page() throws Throwable {
		By headerLogo = HomeTestPage.getImgheaderlogo();

		if (driver.findElement(headerLogo).isDisplayed()) {
			Reporter.log("I am in Signup Page.");
		} else {
			Reporter.log("Error Occured..");
		}
	}

	@Given("^I click Sign Up$")
	public void I_click_Sign_Up() throws Throwable {
		By signup = HomeTestPage.getLblsignup();

		driver.findElement(signup).isDisplayed();
		driver.findElement(signup).click();
	}

	@When("^I click FAQ link$")
	public void I_click_FAQ_link() throws Throwable {
		By lnkFAQ = HomeTestPage.getLblfaq();

		driver.findElement(lnkFAQ).isDisplayed();
		driver.findElement(lnkFAQ).click();
	}
}
