package main.java.com.wireplatform.StepDefinitions;

import main.java.com.wireplatform.CommonUtils;
import main.java.com.wireplatform.PageFactory.OrderSummaryTestPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import cucumber.api.java.en.Then;

public class OrderSummaryPage extends CommonUtils {
	@Then("^I see order summary page$")
	public void I_see_order_summary_page() throws Throwable {
		By lnkordSummary = OrderSummaryTestPage.getLnkordersummary();

		WebDriverWait wait = new WebDriverWait(driver, 20);

		// find the searchBox element and save it in the WebElement variable
		WebElement searchBoxElement = wait.until(ExpectedConditions
				.elementToBeClickable(lnkordSummary));

		if (searchBoxElement.isDisplayed()) {
			Reporter.log("Sign up successfully");
		} else {
			Reporter.log("Unsuccessful..Failed to Sign Up..");
		}
		
		driver.close();
		driver.quit();
	}
}
