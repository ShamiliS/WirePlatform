package main.java.com.wireplatform.StepDefinitions;

import java.util.Set;

import main.java.com.wireplatform.CommonUtils;
import main.java.com.wireplatform.PageFactory.HelpandSupportTestPage;

import org.openqa.selenium.By;
import org.testng.Reporter;

import cucumber.api.java.en.Then;

public class HelpandSupportPage extends CommonUtils {

	@Then("^I should see Advice and answers page$")
	public void I_should_see_Advice_and_answers_page() throws Throwable {
		By lblheader = HelpandSupportTestPage.getLblheader();

		Set<String> AllWindowHandles = driver.getWindowHandles();
		String window2 = (String) AllWindowHandles.toArray()[1];
		driver.switchTo().window(window2);

		if (driver.findElement(lblheader).isDisplayed()) {
			Reporter.log("Navigated to Support page successfully");
		} else {
			Reporter.log("Error on page..");
		}

	}

	@Then("^I enter a valid \"([^\"]*)\"$")
	public void I_enter_a_valid_search_term(String searchterm) throws Throwable {
		By edtSearchbox = HelpandSupportTestPage.getEdtsearch();

		driver.findElement(edtSearchbox).click();
		driver.findElement(edtSearchbox).sendKeys(searchterm);
	}

	@Then("^I should see list of search results$")
	public void I_should_see_list_of_search_results() throws Throwable {

		By lblsearchcontent = HelpandSupportTestPage.getLblsearchcontent();

		String searchterm = driver.findElement(lblsearchcontent).getText();
		if (!searchterm.equals("")) {
			Reporter.log("Search Result for the term " + searchterm
					+ " is displayed successfully");
		} else {
			Reporter.log("No Search Result is displayed");
		}

		driver.close();
		driver.quit();
	}
}
