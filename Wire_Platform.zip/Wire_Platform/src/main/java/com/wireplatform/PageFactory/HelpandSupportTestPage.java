package main.java.com.wireplatform.PageFactory; 

import org.openqa.selenium.By;

public class HelpandSupportTestPage {

	public static final By lblheader = By
			.xpath("//h1[@class='header__headline']");

	public static final By edtsearch = By.id("searchBox");

	public static final By btnsearch = By.xpath("//button[@type='submit']");

	public static final By lblsearch = By
			.xpath("//*[text()='Search results for:']");
	
	public static final By lblsearchcontent = By
			.xpath("//div[@class='section__content']");

	public static By getLblheader() {
		return lblheader;
	}

	public static By getEdtsearch() {
		return edtsearch;
	}

	public static By getBtnsearch() {
		return btnsearch;
	}

	public static By getLblsearch() {
		return lblsearch;
	}

	public static By getLblsearchcontent() {
		return lblsearchcontent;
	}
	
	
}
